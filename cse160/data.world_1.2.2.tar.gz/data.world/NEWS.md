# 1.2.2

* When insight add-in is activated but package is not attached, attempt to load saved configuration
* Clarify error message that is displayed if environment is not configured
* Gracefully handle activation of add-in if user has no suitable projects

# 1.2.1

* Set explicit versoin for dwapi dependency
* Fix installation and load issue related to use of `.onLoad`

# 1.2.0

* Introduce "Add Insight" add-in
* Improve reloading of saved API tokens
* Address compatibility issues with `testthat` 2.0

# 1.1.1

* Address requests from CRAN reviewers related to 1.1.0

# 1.1.0

* Delete all defunct and deprecated functions
* First attempted CRAN release
