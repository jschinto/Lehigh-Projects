Jake Schinto
————————————————
Manifest.txt - used for creating jar
ojdbc7.jar - used to connect to sql
TookCourse - contains all the java classes
TookCourse.class - compiled class
TookCourse.jar - executable