Jake Schinto
————————————————
Manifest.txt - used for creating jar
ojdbc7.jar - used to connect to sql

There are two major interfaces, the first is customer, which can add items to cart and checkout and such.  Customer is also split into an in store half as well as an online half.

The other is for managers that can add products and view reports on how the company is doing.

I used data from a census text file to generate the names.

If I had more time I would really like to implement more store level tasks like from a manager level.  Also add more rankings because those were cool to see.