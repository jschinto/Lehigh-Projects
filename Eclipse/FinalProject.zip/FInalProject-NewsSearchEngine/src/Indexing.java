import java.util.ArrayList;
import java.util.HashMap;

/**
 * takes the tagged files and creates a binary search tree of the terms and
 * sorts by alphabetical order of terms
 * 
 * @author Romeo - 33%
 * @author Matt - 33%
 * @author jake - 33%
 * @version 2017.04.30
 * 
 */
public class Indexing {
    HashMap<String, HashMap<String, Double>> input;
    BinarySearchTree<Term> tree;

    /**
     * Constructor takes an input, creates a tree and calls createIndex() O(1)
     * 
     * @param inInput
     *            sets input
     */
    public Indexing(HashMap<String, HashMap<String, Double>> inInput) {
        input = inInput;
        tree = new BinarySearchTree<Term>();
        createIndex();
    }

    /**
     * populates the binary search tree O(nlogn)
     */
    public void createIndex() {
        for (String term : input.keySet()) {
            Term t = new Term(term,
                    new ArrayList<String>(input.get(term).keySet()));
            tree.insert(t);
        }
    }

    /**
     * prints and returns the in order traversal O(n)
     * 
     * @return terms in order traversal
     * 
     */
    public String toInOrderIndex() {
        throw new UnsupportedOperationException(
                "You have not implemented this method.");
    }

    /**
     * returns the list of files that contains the keyword O(logn)
     * 
     * @param keyword
     *            the term searched for
     * @return the arrayList of files containing the term
     * 
     */
    public ArrayList<String> search(String keyword) {
        return tree.find(new Term(keyword, null)).getFiles();
    }

    /**
     * returns the Binary Search Tree mainly for testing O(1)
     * 
     * @return tree
     * 
     */
    public BinarySearchTree<Term> getTree() {
        return tree;
    }
}