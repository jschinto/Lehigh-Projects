import student.TestCase;
import java.util.ArrayList;

/**
 * @author Romeo - 33%
 * @author Matt - 33%
 * @author jake - 33%
 * @version 2017.05.01
 */
public class TFIDFTest extends TestCase {

    private TFIDF test;
    private ArrayList<String> terms;
    private ArrayList<String> terms1;
    private String term;

    /**
     * empty constructor
     */
    public TFIDFTest() {
        // empty constructor
    }

    /**
     * set up method
     */
    public void setUp() {
        term = "HI";
        test = new TFIDF(term);
        terms = new ArrayList<String>();
        terms.add("HI");
        terms.add("HI");
        terms.add("BYE");
        terms.add("HI");
        terms.add("LOL");
        terms1 = new ArrayList<String>();
        terms.add("BYE");
        terms.add("BYE");
        terms.add("BYE");
        terms.add("BYE");

    }

    /**
     * tests count method
     */
    public void testCount() {
        assertEquals(3, test.Count(terms, term));
    }

    /**
     * test tf method O(n)
     */

    public void testTF() {
        test.Count(terms, term);
        test.tf(terms, term);
        assertEquals(3, test.getTf());
    }

    /**
     * test idf method O(n)
     */

    public void testIDF() {
        test.Count(terms, term);
        test.idf(terms, term);
        assertEquals(1 / 2, test.getIdf());
    }

    /**
     * test tfidf method O(1)
     */

    public void testTFIDF() {
        test.Count(terms, term);
        test.tf(terms, term);
        test.idf(terms, term);
        test.tfidf(terms, term);
        ;
        assertEquals(3 / 2, test.getTfidf());
    }
}
