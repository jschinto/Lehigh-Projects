import java.util.ArrayList;
import java.util.HashMap;

/**
 * Calculates the TFIDF value of a term in a file
 * 
 * @author Romeo - 33%
 * @author Matt - 33%
 * @author jake - 33%
 * @version 2017.04.30
 * 
 */
public class TFIDF {
    private String term;
    private double tf;
    private double idf;
    private double tfidf;

    /**
     * Constructor sets the term and initial values O(1)
     * 
     * @param term
     *            sets term
     *
     */
    public TFIDF(String term) {
        this.term = term;
        this.tf = 0.0;
        this.idf = 0.0;
        this.tfidf = 0.0;
    }

    /**
     * returns the term O(1)
     * 
     * @return term
     * 
     */
    public String getTerm() {
        return term;
    }

    /**
     * returns the tf O(1)
     * 
     * @return tf
     * 
     */
    public double getTf() {
        return tf;
    }

    /**
     * returns the idf O(1)
     * 
     * @return idf
     * 
     */
    public double getIdf() {
        return idf;
    }

    /**
     * returns the tfidf O(1)
     * 
     * @return tfidf
     * 
     */
    public double getTfidf() {
        return tfidf;
    }

    /**
     * Computes the Term frequency O(n)
     * 
     * @return the Term Frequency
     */
    public void tf(ArrayList<String> terms, String term) {
        throw new UnsupportedOperationException(
                "You have not implemented the insert method.");
    }

    /**
     * Computes the Inverse Document Frequency O(n)
     * 
     * @return the inverse document frequency
     */
    public void idf(ArrayList<String> terms, String term) {
        throw new UnsupportedOperationException(
                "You have not implemented the insert method.");
    }

    /**
     * Computes the TFIDF O(1)
     * 
     * @return the value of TFIDF
     */
    public void tfidf(ArrayList<String> terms, String term) {
        throw new UnsupportedOperationException(
                "You have not implemented the insert method.");
    }

    /**
     * Counts the times the term appears in Array O(n)
     * 
     * @param List
     * @param term
     * @return count
     */
    public int Count(ArrayList<String> List, String term) {
        throw new UnsupportedOperationException(
                "You have not implemented the insert method.");
    }
}
