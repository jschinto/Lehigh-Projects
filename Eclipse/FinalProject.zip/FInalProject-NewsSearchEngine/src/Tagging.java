import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Tagging class takes the result from the file parser and tags each file with
 * the terms associated with it
 * 
 * @author Romeo - 33%
 * @author Matt - 33%
 * @author jake - 33%
 * @version 2017/01/5
 * 
 * 
 */
public class Tagging {
    private HashMap<String, HashMap<String, Double>> hm;
    private FilesParser parser;

    /**
     * Constructor parses the file and sends the terms to get TFIDF calculated
     * 
     * @param url
     *            file url
     * 
     * 
     */
    public Tagging(File url) {
        hm = new HashMap<String, HashMap<String, Double>>();
        parser = new FilesParser();
        try {
            parser.parse(url);
        }
        catch (Exception e) {
            // do nothing
        }
        TFIDF(parser.getContent());
    }

    /**
     * Parses and the files and assign it to the fileHm Get each term and call
     * the TFIDF from the TFIDF class and push the article, the name of the
     * file, and the TFIDF value to tags. Gets the TFIDF and stores it in a
     * HashMap if TFIDF is greater than zero O(n^2)
     * 
     * @param term
     *            list of terms
     * 
     * 
     */
    public void TFIDF(HashMap<String, ArrayList<String>> term) {
        // puts each tfidf into hm
        for (String key : term.keySet()) {
            for (String keyword : term.get(key)) {
                // create TFIDF and put into hm
            }
        }
    }

    /**
     * returns the hashmap O(1)
     * 
     * @return hm
     */
    public HashMap<String, HashMap<String, Double>> getTags() {
        return hm;
    }
}