//1
int bitAnd(int, int);
int test_bitAnd(int, int);
int isTmax(int);
int test_isTmax(int);
int tmin();
int test_tmin();
int evenBits();
int test_evenBits();
//2
int anyEvenBit();
int test_anyEvenBit();
int byteSwap(int, int, int);
int test_byteSwap(int, int, int);
int dividePower2(int, int);
int test_dividePower2(int, int);
//3
int bitMask(int, int);
int test_bitMask(int, int);
int isAsciiDigit(int);
int test_isAsciiDigit(int);
int isLessOrEqual(int, int);
int test_isLessOrEqual(int, int);
//4
int bitParity(int);
int test_bitParity(int);
int bang(int);
int test_bang(int);
//float
unsigned floatAbsVal(unsigned);
unsigned test_floatAbsVal(unsigned);
int floatIsLess(unsigned, unsigned);
int test_floatIsLess(unsigned, unsigned);
unsigned floatScale2(unsigned);
unsigned test_floatScale2(unsigned);
